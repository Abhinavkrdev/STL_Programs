/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <array>
#include <bits/stdc++.h>

using namespace std;

int main()
{
    array<int,3>a1;
    array<int,3>::iterator it;
    int i=0;
    int largest=0;
    for(it=a1.begin();it!=a1.end();it++)
    {
      cin>>*(it);
      i++;
    }
    sort(a1.begin(),a1.end());
    for(it=a1.begin();it!=a1.end();it++)
      cout <<*it<<" ";
    return 0;
}