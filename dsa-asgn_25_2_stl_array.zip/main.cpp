/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream>
#include <array>

using namespace std;

int main()
{
    array<float,5>a1 = {34.2,98.1,2.34,45.0,1.50};
    array<float,5>::iterator it;
    float sum=0;
    int i=0;
    for(it=a1.end();it!=a1.begin();it--)
    {
      cout<<*(it-1)<<" ";
      sum=sum+*(it-1);
      i++;
    }
      cout <<i<<endl;
      cout << endl<< sum/i;

    return 0;
}