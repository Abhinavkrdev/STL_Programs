/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream>
#include <array>

using namespace std;

int main()
{
    array<int,5>a1 = {34,98,2,45,1};
    array<int,5>::iterator it;
    for(it=a1.end();it!=a1.begin();it--)
    {
      cout<<*(it-1)<<" ";
    }
    //it=a1.begin();
    
    return 0;
}
